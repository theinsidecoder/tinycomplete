import random

import pytest

from tinycomplete import Autocomplete


def make():
    return Autocomplete.from_words(
        [("python", 90), ("pytest", 40), ("pyramid", 40), ("java", 70), ("javascript", 85), ("go", 60)]
    )


def test_ranked_by_weight():
    assert make().suggest("py") == ["python", "pyramid", "pytest"]  # tie -> alphabetical


def test_k_limits_results():
    assert make().suggest("", k=2) == ["python", "javascript"]


def test_no_match_and_bad_k():
    ac = make()
    assert ac.suggest("zzz") == []
    assert ac.suggest("py", k=0) == []


def test_case_insensitive_by_default():
    assert make().suggest("PY", k=1) == ["python"]


def test_case_sensitive_mode():
    ac = Autocomplete(case_sensitive=True)
    ac.add("Apple", 1)
    assert ac.suggest("a") == []
    assert ac.suggest("A") == ["Apple"]


def test_bump_changes_ranking():
    ac = make()
    ac.bump("pytest", 100)
    assert ac.suggest("py", k=1) == ["pytest"]


def test_lowering_weight_updates_best():
    ac = make()
    ac.add("python", 1)
    assert ac.suggest("py", k=1) == ["pyramid"]


def test_remove_and_prune():
    ac = make()
    assert ac.remove("python") is True
    assert ac.remove("python") is False
    assert "python" not in ac
    assert "pytest" in ac
    assert len(ac) == 5
    assert ac.suggest("pyt") == ["pytest"]
    ac.remove("pytest")
    assert ac.suggest("pyt") == []


def test_empty_word_rejected():
    with pytest.raises(ValueError):
        Autocomplete().add("")


def test_save_load_roundtrip(tmp_path):
    ac = make()
    f = tmp_path / "ac.json"
    ac.save(str(f))
    loaded = Autocomplete.load(str(f))
    assert sorted(loaded.items()) == sorted(ac.items())
    assert loaded.suggest("ja") == ac.suggest("ja")


def test_matches_brute_force_on_random_data():
    rng = random.Random(7)
    words = {"".join(rng.choice("abc") for _ in range(rng.randint(1, 6))): rng.randint(1, 20) for _ in range(400)}
    ac = Autocomplete.from_words(words.items())
    for _ in range(30):  # also exercise remove + re-add
        w = rng.choice(list(words))
        ac.remove(w)
        words.pop(w, None)
    for prefix in ["", "a", "b", "ab", "abc", "cc", "bca"]:
        expected = sorted(((w, s) for w, s in words.items() if w.startswith(prefix)), key=lambda t: (-t[1], t[0]))[:5]
        assert ac.suggest_with_scores(prefix, 5) == expected
