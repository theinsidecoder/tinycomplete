"""Command line: python -m tinycomplete words.txt [prefix] [-k 5]

File format: one entry per line, optionally `phrase<TAB>weight`.
"""

import argparse
import sys

from .engine import Autocomplete


def load_file(path: str) -> Autocomplete:
    ac = Autocomplete()
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            if "\t" in line:
                word, w = line.rsplit("\t", 1)
                ac.add(word, float(w))
            else:
                ac.add(line)
    return ac


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="tinycomplete", description="Tiny autocomplete engine")
    p.add_argument("file", help="word list (optionally word<TAB>weight)")
    p.add_argument("prefix", nargs="?", help="prefix to complete; omit for interactive mode")
    p.add_argument("-k", type=int, default=5, help="number of suggestions (default 5)")
    args = p.parse_args(argv)

    ac = load_file(args.file)
    if args.prefix is not None:
        for word, score in ac.suggest_with_scores(args.prefix, args.k):
            print(f"{word}\t{score:g}")
        return 0

    print(f"Loaded {len(ac)} entries. Type a prefix (empty line to quit).")
    while True:
        try:
            prefix = input("> ")
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not prefix:
            return 0
        for word, score in ac.suggest_with_scores(prefix, args.k):
            print(f"  {word}  ({score:g})")


if __name__ == "__main__":
    sys.exit(main())
