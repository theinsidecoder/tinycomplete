"""tinycomplete: a tiny, dependency-free autocomplete engine (Trie + Heap)."""

from .engine import Autocomplete

__all__ = ["Autocomplete"]
__version__ = "0.1.0"
